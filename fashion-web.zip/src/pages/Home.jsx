import React from "react";
import Categories from "../components/Categories";
import Navbar from "../components/Navbar";
import NewArrival from "../components/NewArrival";
import Spotllight from "../components/Spotlight";
import Topbar from "../components/Topbar";
import DiscountBanner from "../components/DiscountBanner";
import Feedback from "../components/Feedback";
import Footer from "../components/Footer";

const Home = () => {
    return (
        <div>
            <Navbar />
            <Topbar />
            <Spotllight />
            <Categories />
            <NewArrival />
            <DiscountBanner />
            <Feedback />
            <Footer />
        </div>
    );
};

export default Home;
