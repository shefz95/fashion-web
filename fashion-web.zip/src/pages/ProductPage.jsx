import React, { useState, useEffect } from "react";
import { useParams } from "react-router";
import styled from "styled-components";
import Navbar from "../components/Navbar";
import Topbar from "../components/Topbar";
import titan from "../img/titan.jpg";
import star from "../img/star.png";
import share from "../img/share.png";
import Button from "@mui/material/Button";
import cart from "../img/cart-icon.png";
import check from "../img/check.png";
import Feedback from "../components/Feedback";
import Footer from "../components/Footer";
import Products from "../components/Products";
import { Link } from "react-router-dom";

const ProductPage = () => {
    const { id } = useParams();

    const [product, setProduct] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const getProduct = async () => {
            setLoading(true);
            const response = await fetch(
                `https://fakestoreapi.com/products/${id}`
            );
            setProduct(await response.json());
            setLoading(false);
        };
        getProduct();
    }, []);

    const Loading = () => {
        return <>Loading.....</>;
    };
    const ShowProduct = () => {
        const [count, setCount] = useState(0);
        function increment() {
            setCount(function (prevCount) {
                return (prevCount += 1);
            });
        }
        function decrement() {
            setCount(function (prevCount) {
                if (prevCount > 0) {
                    return (prevCount -= 1);
                } else {
                    return (prevCount = 0);
                }
            });
        }
        return (
            <ProductSingle>
                <Navbar />
                <Topbar />
                <ProductSpot>
                    <SpotLeft>
                        <Breads>
                            Home {">"} Shop {">"} {product.category} {">"}{" "}
                            {product.title}
                        </Breads>
                        <SpotHead className="mainHeading">
                            {product.title}
                        </SpotHead>
                    </SpotLeft>
                    <SpotRight
                        style={{
                            backgroundImage: `url(${titan})`,
                            backgroundRepeat: "no-repeat",
                            backgroundSize: "cover",
                        }}
                    ></SpotRight>
                </ProductSpot>
                <ProductInfo>
                    <ProductImages
                        style={{
                            backgroundImage: `url(${product.image})`,
                            backgroundRepeat: "no-repeat",
                            backgroundSize: "contain",
                            backgroundPosition: "center",
                        }}
                    ></ProductImages>
                    <InfoDetails>
                        <InfoHead className="mainHeading">
                            {product.title}
                        </InfoHead>
                        <Available>
                            Avaliability :<b>100 in stocks</b>
                        </Available>
                        <PriceInfo>
                            <Price>
                                <DiscountPrice>${product.price}</DiscountPrice>
                                <OriginalPrice>$1500</OriginalPrice>
                            </Price>
                            <ShareBtn>
                                Share &nbsp; <img src={share} alt="icon" />
                            </ShareBtn>
                        </PriceInfo>

                        <Information>
                            <Sub>SKU</Sub>
                            <Text>: {product.id}</Text>
                        </Information>
                        <Information>
                            <Sub>Category</Sub>
                            <Text>: {product.category}</Text>
                        </Information>
                        <Information>
                            <Sub>Tags</Sub>
                            <Text>: Fashion, Classic, Blouses, Dresses</Text>
                        </Information>

                        <Selections>
                            <Select>
                                <Option disabled selected hidden>
                                    Select Size
                                </Option>
                                <Option>S</Option>
                                <Option>M</Option>
                                <Option>L</Option>
                                <Option>XL</Option>
                            </Select>
                            <Counter>
                                <CountBtn onClick={decrement}>-</CountBtn>
                                <Count>{count}</Count>
                                <CountBtn onClick={increment}>+</CountBtn>
                            </Counter>
                            <Note>Add Note</Note>
                        </Selections>
                        <CartOptions>
                            <Link to="/cart">
                                <Button className="orangeBtn">
                                    Add to Cart &nbsp;{" "}
                                    <img src={cart} alt="image" />
                                </Button>
                            </Link>
                            <Shortlist>
                                <img src={star} alt="icon" />
                            </Shortlist>
                        </CartOptions>
                    </InfoDetails>
                </ProductInfo>
                <DescriptionInfo>
                    <Description>
                        <Header className="subHeading">Description</Header>
                        <Text>{product.description}</Text>
                    </Description>
                    <FabricDetails>
                        <Header className="subHeading">FabricDetails</Header>
                        <FabricInfo>
                            <Info>
                                <img src={check} alt="image" />
                                &nbsp; 100% Cotton
                            </Info>
                            <Info>
                                <img src={check} alt="image" />
                                &nbsp; Ties as Shoulder
                            </Info>
                            <Info>
                                <img src={check} alt="image" />
                                &nbsp; Quick Dry
                            </Info>
                        </FabricInfo>
                    </FabricDetails>
                </DescriptionInfo>
                <CheckHead className="mainHeading">Related Items</CheckHead>
                <Products />
                <Feedback />
                <Footer />
            </ProductSingle>
        );
    };

    return <div>{loading ? <Loading /> : <ShowProduct />}</div>;
};
const CheckHead = styled.h1`
    margin: 30px 10% 60px;
`;
const ProductSingle = styled.div`
    font-family: "DM Sans";
`;
const ProductSpot = styled.div`
    display: flex;
    align-items: center;
    padding-left: 75px;
    justify-content: space-between;
    @media (max-width: 1080px) {
        padding-left: 30px;
    }
    @media (max-width: 640px) {
        padding-left: 0;
        flex-direction: column;
    }
`;
const SpotLeft = styled.div`
    @media (max-width: 640px) {
        text-align: center;
    }
`;
const Breads = styled.p`
    font-family: "Merriweather";
    font-weight: 600;
    @media (max-width: 1080px) {
        max-width: 80%;
        line-height: 30px;
    }
    @media (max-width: 640px) {
        text-align: center;
        margin: 0 auto;
    }
`;
const SpotHead = styled.h1``;
const SpotRight = styled.div`
    width: 50%;
    height: 420px;
    @media (max-width: 980px) {
        width: 75%;
    }
    @media (max-width: 640px) {
        width: 100%;
    }
`;
const ProductInfo = styled.div`
    display: flex;
    align-items: center;
    max-width: 80%;
    margin: 50px auto;
    border-bottom: 1px solid #e1e1e1;
    padding-bottom: 75px;
    @media (max-width: 1080px) {
        max-width: 90%;
    }
    @media (max-width: 768px) {
        margin: 50px auto 25px;
        padding-bottom: 50px;
        flex-direction: column;
    }
`;
const ProductImages = styled.div`
    height: 420px;
    width: 50%;
    margin-right: 50px;
    @media (max-width: 1080px) {
        width: 65%;
    }
    @media (max-width: 860px) {
        width: 75%;
    }
    @media (max-width: 768px) {
        margin-right: 0;
        margin-bottom: 30px;
    }
`;
const InfoDetails = styled.div``;
const InfoHead = styled.h1``;
const Available = styled.p`
    font-family: "Merriweather";
`;
const PriceInfo = styled.div`
    display: flex;
    margin-bottom: 30px;
    align-items: baseline;
    justify-content: space-between;
`;
const Price = styled.div`
    display: flex;
    align-items: center;
`;
const DiscountPrice = styled.h5`
    font-family: "Merriweather";
    color: #f3692e;
    font-size: 32px;
    margin: 5px 15px 10px 0;
`;
const OriginalPrice = styled.div`
    font-family: "Merriweather";
    color: #9a9ab0;
    text-decoration: line-through;
    font-size: 16px;
`;
const ShareBtn = styled.div`
    font-family: "Merriweather";
    display: flex;
`;
const Select = styled.select`
    font-family: "DM Sans";
    padding: 6px 9px;
    border-radius: 3px;
    border: 1px solid #000;
`;
const Option = styled.option``;
const Selections = styled.div`
    display: flex;
    align-items: center;
    margin: 20px 0 40px;
    justify-content: space-between;
`;
const Counter = styled.div`
    display: flex;
    align-items: baseline;
`;
const CountBtn = styled.button`
    background: transparent;
    border: none;
    font-size: 30px;
`;
const Count = styled.h2`
    font-size: 25px;
    margin: 0 25px;
    font-weight: 500;
`;
const Note = styled.span`
    font-family: "Merriweather";
    color: #f3692e;
    cursor: pointer;
    font-weight: 600;
`;
const CartOptions = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
`;
const Shortlist = styled.div`
    border: 3px solid #f3692e;
    border-radius: 9px;
    cursor: pointer;
    padding: 12px 15px 9px 14px;
`;
const Information = styled.div`
    display: flex;
    align-items: baseline;
`;
const Sub = styled.span`
    font-family: "Merriweather";
    font-size: 15px;
    font-weight: 600;

    width: 99px;
    margin-bottom: 15px;
`;
const Text = styled.span`
    font-family: "DM Sans";
    color: #666;
`;
const DescriptionInfo = styled.div`
    display: flex;
    width: 80%;
    margin: 0 auto;
    @media (max-width: 860px) {
        width: 90%;
    }
    @media (max-width: 768px) {
        flex-direction: column;
    }
`;
const Description = styled.div`
    width: 70%;
    margin-right: 35px;
`;
const Header = styled.h3``;
const FabricDetails = styled.div``;
const FabricInfo = styled.div``;
const Info = styled.div`
    display: flex;
    align-items: center;
    color: #515151;
    margin-bottom: 15px;
`;

export default ProductPage;
