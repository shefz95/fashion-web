import React, { useEffect, useState } from "react";
import styled from "styled-components";
import Navbar from "../components/Navbar";
import Topbar from "../components/Topbar";
import mars from "../img/mars.jpg";
import like from "../img/heart-orange.png";
import two from "../img/two.jpg";
import icon from "../img/delete.png";
import { Button } from "@mui/material";
import FormValidation from "../components/Form";
import { NavLink } from "react-router-dom";
import Skeleton from "react-loading-skeleton";
import Footer from "../components/Footer";
const Cart = () => {
    const [loading, setLoading] = useState(false);
    const [filtered, setFiltered] = useState([]);
    let componentMount = true;
    const [datas, setDatas] = useState([]);
    useEffect(() => {
        const getRecommended = async () => {
            setLoading(true);
            const response = await fetch(
                "https://fakestoreapi.com/products/category/electronics"
            );
            if (componentMount) {
                setDatas(await response.clone().json());
                setFiltered(await response.json());
                setLoading(false);
                console.log(filtered);
            }
            return () => {
                componentMount = false;
            };
        };
        getRecommended();
    }, []);

    const Loading = () => {
        return (
            <div>
                <Skeleton height={350} />
            </div>
        );
    };

    return (
        <div>
            <Navbar />
            <Topbar />
            <CartSpot>
                <SpotLeft>
                    <Breads>Home {">"} Shopping Bag</Breads>
                    <SpotHead className="mainHeading">Shopping Bag</SpotHead>
                </SpotLeft>
                <SpotRight
                    style={{
                        backgroundImage: `url(${mars})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover",
                    }}
                ></SpotRight>
            </CartSpot>
            <CartWrap>
                <h1 className="mainHeadiing">Cart</h1>
                <CartHeader>
                    <HeadText></HeadText>
                    <HeadText>Product Name</HeadText>
                    <HeadText>Price</HeadText>
                    <HeadText>Quantity</HeadText>
                    <HeadText>Total</HeadText>
                </CartHeader>
                <CartItem>
                    <ItemImg
                        style={{
                            backgroundImage: `url(${two})`,
                            backgroundRepeat: "no-repeat",
                            backgroundSize: "cover",
                            backgroundPosition: "center",
                        }}
                    ></ItemImg>
                    <ItemText>Classic Blouse IX</ItemText>
                    <ItemText>$ 99</ItemText>
                    <ItemText>2</ItemText>
                    <ItemText>$198</ItemText>
                    <Delete>
                        <img src={icon} alt="icon" />
                    </Delete>
                </CartItem>
            </CartWrap>
            <CartBottom>
                <CouponWrap>
                    <h2 className="subHeading">Have a Coupon?</h2>
                    <input
                        type="text"
                        name="coupon"
                        placeholder="Enter Your Code"
                        id="coupon"
                    />
                    <Button className="orangeBtn">Apply Coupon</Button>
                </CouponWrap>

                <CartTotal>
                    <SubHead className="subHeading">Cart Totals</SubHead>
                    <TotalItem>
                        <Sub>Subtotal</Sub>
                        <Text>$150</Text>
                    </TotalItem>
                    <TotalItem>
                        <Sub>Shipping</Sub>
                        <Text>
                            Free Shipping
                            <br />
                            Shipping to Sidney &emsp;
                        </Text>
                        <Text>
                            <Change>Change</Change>
                        </Text>
                    </TotalItem>
                    <GrandTotal>
                        <Sub>Total</Sub>
                        <Text>$1050</Text>
                    </GrandTotal>
                    <Button className="orangeBtn w-100">Checkout</Button>
                </CartTotal>
            </CartBottom>

            <CheckHead className="mainHeading">Checkout</CheckHead>
            <FormValidation />

            <Related>
                <Header className="mainHeading">Related Items</Header>
                <div className="grid">
                    {filtered.map((product) => (
                        <NavLink to={`shop/${product.id}`}>
                            <ProductCardBox key={product.id}>
                                <ProductImage
                                    style={{
                                        backgroundImage: `url(${product.image})`,
                                        backgroundRepeat: "no-repeat",
                                        backgroundSize: "contain",
                                        backgroundPosition: "center",
                                    }}
                                ></ProductImage>
                                <Shortlist>
                                    <img src={like} alt="icon" />
                                </Shortlist>
                                <CardInfo>
                                    <InfoCategory>
                                        {product.category}
                                    </InfoCategory>
                                    <InfoHead>{product.title}</InfoHead>
                                    <InfoSub>{product.description}</InfoSub>
                                    <Price>{product.price}</Price>
                                </CardInfo>
                            </ProductCardBox>
                        </NavLink>
                    ))}
                </div>
            </Related>
            <Footer />
        </div>
    );
};
const CartSpot = styled.div`
    display: flex;

    align-items: center;
    padding-left: 75px;
    justify-content: space-between;
    @media (max-width: 1080px) {
        padding-left: 30px;
    }
    @media (max-width: 640px) {
        padding-left: 0;
        flex-direction: column;
    }
`;
const SpotRight = styled.div`
    width: 50%;
    height: 420px;
    @media (max-width: 980px) {
        width: 65%;
    }
    @media (max-width: 640px) {
        width: 100%;
    }
`;
const SubHead = styled.h2`
    margin: 0 0 40px;
`;
const SpotLeft = styled.div``;
const CheckHead = styled.h1`
    margin: 50px 12% 15px;
`;
const Breads = styled.p`
    font-family: "Merriweather";
    font-weight: 600;
`;
const CartWrap = styled.div`
    font-family: "DM Sans";
    max-width: 75%;
    margin: 65px auto 35px;
    @media (max-width: 1200px) {
        max-width: 85%;
    }
    @media (max-width: 980px) {
        max-width: 95%;
    }
`;
const CartHeader = styled.div`
    display: flex;
    background: #f86338;
    padding: 20px 10px;
    border-radius: 10px;
    margin-bottom: 15px;
    font-size: 16px;
    font-weight: 500;
    color: #fff;
`;
const HeadText = styled.div`
    width: 16.5%;
    @media (max-width: 980px) {
        font-size: 13px;
    }
`;
const CartItem = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr 1fr 1fr;
    padding: 20px 10px;
    border-radius: 10px;
    font-size: 16px;
    align-items: center;
    font-weight: 500;
`;
const SpotHead = styled.div``;
const GrandTotal = styled.div`
    display: flex;
    align-items: center;
    margin-bottom: 40px;
`;
const ItemImg = styled.div`
    width: 75px;
    height: 75px;
`;
const ItemText = styled.div`
    @media (max-width: 980px) {
        font-size: 13px;
    }
`;
const Delete = styled.div`
    text-align: center;
`;
const CartBottom = styled.div`
    display: flex;
    max-width: 75%;
    margin: 30px auto;
    @media (max-width: 1080px) {
        max-width: 90%;
    }
    @media (max-width: 768px) {
        flex-direction: column;
    }
    @media (max-width: 480px) {
        align-items: center;
    }
`;
const CouponWrap = styled.div`
    width: 33%;
    margin-right: 99px;
    background: #ffefeb;
    padding: 20px 80px 40px 40px;
    border-radius: 10px;
    @media (max-width: 1080px) {
        width: 36%;
        margin-right: 66px;
    }
    @media (max-width: 940px) {
        width: 30%;
        margin-right: 30px;
    }
    @media (max-width: 768px) {
        width: 75%;
        margin-right: 0;
        margin-bottom: 40px;
    }
    @media (max-width: 480px) {
        width: 50%;
    }
`;
const CartTotal = styled.div``;
const TotalItem = styled.div`
    display: flex;
    align-items: center;
    margin-bottom: 25px;
`;
const Sub = styled.div`
    font-family: "Merriweather";
    font-weight: 700;
    font-size: 15px;
    width: 125px;
`;
const Text = styled.span`
    color: #515151;
    font-size: 15px;
`;
const Change = styled.span`
    color: #f86338;
    font-size: 15px;
    margin-left: 20px;
    margin-top: 20px;
`;
const Related = styled.div`
    padding-bottom: 75px;
    max-width: 85%;
    margin: 0 auto;
`;
const Header = styled.h1`
    padding: 30px 0 35px 75px;
    @media (max-width: 840px) {
        text-align: center;
        padding-left: 0;
    }
`;
const ProductCardBox = styled.div`
    font-family: "DM Sans";
    position: relative;
    width: 320px;
    box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;
    margin: 0 7px;
    padding: 30px 20px 20px;
    border-radius: 10px;
    &:hover {
        transform: scale(1.03);
        transition: all 0.5s;
    }
    @media (max-width: 480px) {
        width: 260px;
    }
`;
const ProductImage = styled.div`
    height: 300px;
`;

const Shortlist = styled.div`
    position: absolute;
    top: 15px;
    right: 15px;
    cursor: pointer;
    background-color: #fff;
    padding: 8px 8px 4px 8px;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    border-radius: 53px;
`;
const CardInfo = styled.div`
    text-align: center;
    margin-top: 20px;
`;
const InfoCategory = styled.span`
    font-size: 14px;
    color: #f3692e;
`;
const InfoHead = styled.h2`
    font-family: "Merriweather";
    color: #11142d;

    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;

    font-size: 24px;
    margin: 5px 0 10px;
`;
const InfoSub = styled.span`
    color: #515151;
    font-size: 13px;

    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
`;
const Price = styled.h5`
    font-family: "Merriweather";
    color: #f3692e;
    font-size: 24px;
    margin: 9px 0;
`;
export default Cart;
