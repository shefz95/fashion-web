import Topbar from "../components/Topbar";
import mars from "../img/mars.jpg";
import Navbar from "../components/Navbar";
import React, { useEffect, useState } from "react";
import Skeleton from "react-loading-skeleton";
import styled from "styled-components";
import like from "../img/heart-orange.png";
import { NavLink } from "react-router-dom";
import Footer from "../components/Footer";

const Shop = () => {
    const [loading, setLoading] = useState(false);
    const [filter, setFilter] = useState([]);
    let componentMounted = true;
    const [data, setData] = useState([]);
    useEffect(() => {
        const getProducts = async () => {
            setLoading(true);
            const response = await fetch("https://fakestoreapi.com/products");
            if (componentMounted) {
                setData(await response.clone().json());
                setFilter(await response.json());
                setLoading(false);
                console.log(filter);
            }
            return () => {
                componentMounted = false;
            };
        };
        getProducts();
    }, []);

    const [filtered, setFiltered] = useState([]);
    let componentMount = true;
    const [datas, setDatas] = useState([]);
    useEffect(() => {
        const getRecommended = async () => {
            setLoading(true);
            const response = await fetch(
                "https://fakestoreapi.com/products/category/jewelery"
            );
            if (componentMount) {
                setDatas(await response.clone().json());
                setFiltered(await response.json());
                setLoading(false);
                console.log(filtered);
            }
            return () => {
                componentMount = false;
            };
        };
        getRecommended();
    }, []);

    const Loading = () => {
        return (
            <div>
                <Skeleton height={350} />
            </div>
        );
    };

    const filterProduct = (cat) => {
        const updatedList = data.filter((x) => x.category === cat);
        setFilter(updatedList);
    };

    return (
        <div>
            <Navbar />
            <Topbar />
            <ShopSpot>
                <SpotLeft>
                    <Breads>Home {">"} Shop</Breads>
                    <SpotHead className="mainHeading">Shop</SpotHead>
                </SpotLeft>
                <SpotRight
                    style={{
                        backgroundImage: `url(${mars})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover",
                    }}
                ></SpotRight>
            </ShopSpot>

            <TabsListing className="tabsList">
                <button onClick={() => setFilter(data)}>All</button>
                <button onClick={() => filterProduct("men's clothing")}>
                    Men's Clothing
                </button>
                <button onClick={() => filterProduct("jewelery")}>
                    Jewellery
                </button>
                <button onClick={() => filterProduct("electronics")}>
                    Electronics
                </button>
                <button onClick={() => filterProduct("women's clothing")}>
                    Women's Clothing
                </button>
            </TabsListing>

            <ProductsWrap>
                <div className="grid">
                    {loading && <Loading />}

                    {filter.map((product) => (
                        <NavLink to={`shop/${product.id}`}>
                            <ProductCardBox key={product.id}>
                                <ProductImage
                                    style={{
                                        backgroundImage: `url(${product.image})`,
                                        backgroundRepeat: "no-repeat",
                                        backgroundSize: "contain",
                                        backgroundPosition: "center",
                                    }}
                                ></ProductImage>
                                <Shortlist>
                                    <img src={like} alt="icon" />
                                </Shortlist>
                                <CardInfo>
                                    <InfoCategory>
                                        {product.category}
                                    </InfoCategory>
                                    <InfoHead>{product.title}</InfoHead>
                                    <InfoSub>{product.description}</InfoSub>
                                    <Price>{product.price}</Price>
                                </CardInfo>
                            </ProductCardBox>
                        </NavLink>
                    ))}
                </div>
            </ProductsWrap>

            <Recommended>
                <Header className="mainHeading">Recommended for you</Header>
                <div className="grid">
                    {filtered.map((product) => (
                        <NavLink to={`shop/${product.id}`}>
                            <ProductCardBox key={product.id}>
                                <ProductImage
                                    style={{
                                        backgroundImage: `url(${product.image})`,
                                        backgroundRepeat: "no-repeat",
                                        backgroundSize: "contain",
                                        backgroundPosition: "center",
                                    }}
                                ></ProductImage>
                                <Shortlist>
                                    <img src={like} alt="icon" />
                                </Shortlist>
                                <CardInfo>
                                    <InfoCategory>
                                        {product.category}
                                    </InfoCategory>
                                    <InfoHead>{product.title}</InfoHead>
                                    <InfoSub>{product.description}</InfoSub>
                                    <Price>{product.price}</Price>
                                </CardInfo>
                            </ProductCardBox>
                        </NavLink>
                    ))}
                </div>
            </Recommended>

            <Footer />
        </div>
    );
};
const ShopSpot = styled.div`
    display: flex;
    align-items: center;
    padding-left: 75px;
    justify-content: space-between;
    @media (max-width: 768px) {
        padding-left: 30px;
    }
    @media (max-width: 480px) {
        flex-direction: column;
        padding-left: 0;
    }
`;
const TabsListing = styled.div``;
const Recommended = styled.div`
    padding-bottom: 75px;
`;
const ProductsWrap = styled.div``;
const SpotLeft = styled.div`
    width: 50%;
    @media (max-width: 980px) {
        width: 70%;
    }
`;
const Breads = styled.p`
    font-family: "Merriweather";
    font-weight: 600;
`;
const SpotHead = styled.h1``;
const Header = styled.h1`
    padding: 30px 0 35px 75px;
`;
const SpotRight = styled.div`
    width: 50%;
    height: 420px;
    @media (max-width: 768px) {
        width: 65%;
    }
    @media (max-width: 480px) {
        width: 100%;
    }
`;

const ProductCardBox = styled.div`
    font-family: "DM Sans";
    position: relative;
    width: 320px;
    box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;
    margin: 0 7px;
    padding: 30px 20px 20px;
    border-radius: 10px;
    &:hover {
        transform: scale(1.03);
        transition: all 0.5s;
    }
    @media (max-width: 480px) {
        width: 260px;
    }
`;
const ProductImage = styled.div`
    height: 300px;
`;
const Shortlist = styled.div`
    position: absolute;
    top: 15px;
    right: 15px;
    cursor: pointer;
    background-color: #fff;
    padding: 8px 8px 4px 8px;
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    border-radius: 53px;
`;
const CardInfo = styled.div`
    text-align: center;
    margin-top: 20px;
`;
const InfoCategory = styled.span`
    font-size: 14px;
    color: #f3692e;
`;
const InfoHead = styled.h2`
    font-family: "Merriweather";
    color: #11142d;

    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;

    font-size: 24px;
    margin: 5px 0 10px;
`;
const InfoSub = styled.span`
    color: #515151;
    font-size: 13px;

    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
`;
const Price = styled.h5`
    font-family: "Merriweather";
    color: #f3692e;
    font-size: 24px;
    margin: 9px 0;
`;
export default Shop;
