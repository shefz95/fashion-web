import React from "react";
import styled from "styled-components";
import button from "../img/button.png";

import jeans from "../img/jeans.jpg";
import tshirts from "../img/tshirts.jpg";
import ethnic from "../img/ethnic.jpg";
import girl from "../img/girl.jpg";
import hood from "../img/hood.jpg";
import jean from "../img/jean.jpg";

const Categories = () => {
    const data = [
        { id: 1, name: "Jeans", description: "jeans", bgUrl: jeans },
        { id: 2, name: "T-Shirts", description: "tshirts", bgUrl: tshirts },
        { id: 3, name: "Ethnic Wear", description: "ethnic", bgUrl: ethnic },
        { id: 4, name: "Baby Girls", description: "baby girl", bgUrl: girl },
        { id: 5, name: "Hoodies", description: "hoodies", bgUrl: hood },
        {
            id: 6,
            name: "Exotic Jeans",
            description: "exotic jeans",
            bgUrl: jean,
        },
    ];
    return (
        <CategoryCards>
            {data.map((category) => (
                <CategoryCard
                    key={category.id}
                    style={{
                        backgroundImage: `url(${category.bgUrl})`,
                        backgroundRepeat: "no-repeat",
                        backgroundSize: "cover",
                    }}
                >
                    <CardInfo>
                        <InfoHead>{category.name}</InfoHead>
                        <InfoSub>{category.description}</InfoSub>
                        <Icon>
                            <img src={button} alt="icon" />
                        </Icon>
                    </CardInfo>
                </CategoryCard>
            ))}
        </CategoryCards>
    );
};
const CategoryCards = styled.div`
    display: grid;
    margin-top: 60px;
    grid-template-columns: 1fr 1fr 1fr;
    grid-gap: 20px;
    max-width: 90%;
    margin: 120px auto 0;
    @media (max-width: 1080px) {
        grid-template-columns: 1fr 1fr;
    }
    @media (max-width: 768px) {
        grid-template-columns: 1fr;
    }
`;
const CategoryCard = styled.div`
    position: relative;
    height: 520px;
    background-color: #ddd;
`;
const CardInfo = styled.div`
    position: absolute;
    bottom: 30px;
    left: 25px;
`;
const InfoHead = styled.h1`
    font-size: 36px;
    color: #11142d;
    font-family: "Merriweather";
`;
const InfoSub = styled.p`
    font-size: 16px;
    font-weight: 500;
    color: #fff;
`;
const Icon = styled.span``;
export default Categories;
