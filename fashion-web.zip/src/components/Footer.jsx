import React from "react";
import logo from "../img/logo-white.png";
import pin from "../img/pin.png";
import email from "../img/email.png";
import call from "../img/call-white.png";
import styled from "styled-components";

const Footer = () => {
    return (
        <FooterMain>
            <Logo>
                <img src={logo} alt="icon" />
            </Logo>
            <FooterContent>
                <FooterLeft>
                    <About>
                        OurStudio is a digital agency UI / UX Design and Website
                        Development located in Ohio, United States of America
                    </About>
                </FooterLeft>

                <FooterMid>
                    <MidHead>Our Social Media</MidHead>
                    <Social>Facebook</Social>
                    <Social>Twitter</Social>
                    <Social>Instagram</Social>
                    <Social>Youtube</Social>
                </FooterMid>
                <FooterRight>
                    <RightHead>Contact</RightHead>
                    <Address>
                        <Icon>
                            <img src={pin} alt="icon" />
                        </Icon>
                        <Text>
                            8819 Ohio St. South Gate,
                            <br /> California 90280
                        </Text>
                    </Address>
                    <Email>
                        <Icon>
                            <img src={email} alt="icon" />
                        </Icon>
                        <Text className="white">
                            <a href="mailto:ourstudio@hello.com">
                                ourstudio@hello.com
                            </a>
                        </Text>
                    </Email>
                    <Phone>
                        <Icon>
                            <img src={call} alt="icon" />
                        </Icon>
                        <Text className="white">
                            <a href="tel:+2713866473637">+271 386-647-3637</a>
                        </Text>
                    </Phone>
                </FooterRight>
            </FooterContent>
            <Copyright>Copyright Tanah Air Studio</Copyright>
        </FooterMain>
    );
};
const FooterMain = styled.div`
    padding: 25px 10px 10px 75px;
    font-family: "DM Sans";
    color: #fff;
    background-color: #f86338;
    @media (max-width: 860px) {
        padding: 25px 10px 10px 30px;
    }
`;
const FooterLeft = styled.div`
    flex: 2;
    @media (max-width: 1080px) {
        flex: 1;
    }
`;
const FooterContent = styled.div`
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    @media (max-width: 1080px) {
        flex-direction: column;
    }
`;
const Logo = styled.div``;
const About = styled.p`
    margin: 0;
    max-width: 60%;
    @media (max-width: 1080px) {
        max-width: 85%;
    }
    @media (max-width: 860px) {
        font-size: 14px;
    }
    @media (max-width: 768px) {
        margin-bottom: 30px;
    }
`;
const FooterMid = styled.div`
    flex: 1;
    @media (max-width: 768px) {
        margin-bottom: 30px;
    }
`;
const MidHead = styled.span`
    font-size: 17px;
    font-weight: 600;
    margin-bottom: 10px;
    @media (max-width: 860px) {
        font-size: 15px;
    }
`;
const Social = styled.p`
    @media (max-width: 860px) {
        font-size: 14px;
    }
`;
const FooterRight = styled.div`
    flex: 1;
`;
const Address = styled.div`
    display: flex;
`;
const Phone = styled.div`
    display: flex;
`;
const Email = styled.div`
    display: flex;
    margin: 20px 0;
`;
const RightHead = styled.span`
    font-size: 17px;
    font-weight: 600;
    margin-bottom: 30px;
`;
const Icon = styled.div``;
const Copyright = styled.p`
    margin: 30px 0 0 0;
    text-align: center;
    @media (max-width: 860px) {
        font-size: 14px;
    }
`;
const Text = styled.p`
    margin: 0 0 0 15px;
    @media (max-width: 860px) {
        font-size: 14px;
    }
`;
export default Footer;
