import React from "react";
import styled from "styled-components";
import logo from "../img/logo.png";
import call from "../img/call.png";
import fb from "../img/fb.png";
import insta from "../img/ig.png";
import yt from "../img/yt.png";
import tweet from "../img/tw.png";

const Navbar = () => {
    return (
        <NavContainer>
            <NavLeft>
                <PhoneIcon>
                    <img src={call} alt="" />
                </PhoneIcon>
                <PhoneNum>+022 319 821 967</PhoneNum>
            </NavLeft>
            <NavMid>
                <img src={logo} alt="" />
            </NavMid>
            <NavRight>
                <SocialIcon>
                    <img src={tweet} alt="" />
                </SocialIcon>
                <SocialIcon>
                    <img src={insta} alt="" />
                </SocialIcon>
                <SocialIcon>
                    <img src={yt} alt="" />
                </SocialIcon>
                <SocialIcon>
                    <img src={fb} alt="" />
                </SocialIcon>
            </NavRight>
        </NavContainer>
    );
};

const NavContainer = styled.div`
    display: flex;
    padding: 35px 80px;
    align-items: center;
    justify-content: space-between;
    @media (max-width: 860px) {
        padding: 30px;
    }
    @media (max-width: 640px) {
        flex-direction: column;
    }
`;
const NavLeft = styled.div`
    display: flex;
    flex: 1;
    align-items: center;
`;
const PhoneIcon = styled.div`
    display: flex;
    margin-right: 9px;
`;
const PhoneNum = styled.span`
    font-family: "DM Sans";
    font-weight: 500;
`;
const NavMid = styled.div`
    text-align: center;
    flex: 1;
    @media (max-width: 640px) {
        margin: 25px 0;
    }
`;
const NavRight = styled.div`
    flex: 1;
    display: flex;
    justify-content: end;
    align-items: center;
`;
const SocialIcon = styled.span`
    margin-left: 15px;
`;

export default Navbar;
