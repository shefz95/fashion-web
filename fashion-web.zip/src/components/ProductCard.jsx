import React from "react";
import styled from "styled-components";
import like from "../img/heart-orange.png";

const ProductCard = (props) => {
    return (
        <ProductCardBox>
            <ProductImage
                style={{
                    backgroundImage: `url(${props.prodImage})`,
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "cover",
                }}
            ></ProductImage>
            <Shortlist>
                <img src={like} alt="icon" />
            </Shortlist>
            <CardInfo>
                <InfoCategory>{props.prodType}</InfoCategory>
                <InfoHead>{props.prodName}</InfoHead>
                <InfoSub>{props.subCategory}</InfoSub>
                <Price>{props.prodPrice}</Price>
            </CardInfo>
        </ProductCardBox>
    );
};
const ProductCardBox = styled.div`
    font-family: "DM Sans";
    position: relative;
    margin: 0 7px;
`;
const ProductImage = styled.div`
    height: 300px;
`;
const Shortlist = styled.div`
    position: absolute;
    top: 15px;
    right: 15px;
    cursor: pointer;
    background-color: #fff;
    padding: 8px 8px 4px 8px;
    border-radius: 53px;
`;
const CardInfo = styled.div`
    text-align: center;
    margin-top: 20px;
`;
const InfoCategory = styled.span`
    font-size: 14px;
    color: #f3692e;
`;
const InfoHead = styled.h2`
    font-family: "Merriweather";
    color: #11142d;
    font-size: 24px;
    margin: 5px 0 10px;
`;
const InfoSub = styled.span`
    color: #515151;
    font-size: 13px;
`;
const Price = styled.h5`
    font-family: "Merriweather";
    color: #f3692e;
    font-size: 24px;
    margin: 9px 0;
`;

export default ProductCard;
