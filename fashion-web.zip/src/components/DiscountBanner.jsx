import { Button } from "@mui/material";
import React from "react";
import styled from "styled-components";
import arrow from "../img/right-arrow.png";

const DiscountBanner = () => {
    return (
        <BannerWrap>
            <BannerCategory>March Discount</BannerCategory>
            <Discount>Up to 70% off</Discount>
            <Button className="whiteBtn">
                Got it&emsp;
                <img src={arrow} alt="icon" />
            </Button>
        </BannerWrap>
    );
};
const BannerWrap = styled.div`
    background-color: #f86338;
    width: 90%;
    text-align: center;
    padding: 75px 0;
    margin: 120px auto;
`;
const BannerCategory = styled.h5`
    font-size: 24px;
    font-family: "Merriweather";
    font-weight: 500;
    margin: 5px 0 10px;
    color: #fff;
`;
const Discount = styled.h1`
    color: #fff;
    font-size: 46px;
    font-family: "Merriweather";
    margin: 5px 0 50px;
`;
export default DiscountBanner;
