import React from "react";
import styled from "styled-components";
import cart from "../img/cart.png";
import user from "../img/user.png";
import like from "../img/like.png";
import { Link } from "react-router-dom";

const Topbar = () => {
    return (
        <TopContainer>
            <TopLeft>
                <NavBtn>
                    <Link to="/">Home</Link>
                </NavBtn>
                <NavBtn>
                    <Link to="/shop">Shop</Link>
                </NavBtn>
                <NavBtn>
                    <Link to="/">FAQ</Link>
                </NavBtn>
                <NavBtn>
                    <Link to="/">Blog</Link>
                </NavBtn>
            </TopLeft>
            <TopRight>
                <LikeBtn>
                    <img src={like} alt="icon" />
                </LikeBtn>
                {/* <NavBtn> */}
                <CartBtn>
                    <Link to="/cart">
                        <img src={cart} alt="icon" />
                    </Link>
                </CartBtn>
                {/* </NavBtn> */}
                <UserBtn>
                    <img src={user} alt="icon" />
                </UserBtn>
            </TopRight>
        </TopContainer>
    );
};

const TopContainer = styled.div`
    display: flex;
    padding: 35px 80px;
    align-items: center;
    justify-content: space-between;
    @media (max-width: 860px) {
        padding: 30px;
    }
    @media (max-width: 480px) {
        flex-direction: column;
        padding-top: 0;
    }
`;
const TopLeft = styled.div`
    display: flex;
    flex: 1;
    align-items: center;
    @media (max-width: 480px) {
        margin-bottom: 20px;
    }
`;
const TopRight = styled.div`
    flex: 1;
    display: flex;
    justify-content: end;
    align-items: center;
`;
const LikeBtn = styled.span``;
const NavBtn = styled.span`
    margin-left: 15px;
    &:first-child {
        margin-left: 0;
    }
`;
const CartBtn = styled.span`
    margin-left: 15px;
`;
const UserBtn = styled.span`
    margin-left: 15px;
`;

export default Topbar;
