import React from "react";
import { Form, Button } from "semantic-ui-react";
import { useForm } from "react-hook-form";
import styled from "styled-components";
const FlexBox = styled.div`
  display: flex;
`;
const FormWrap = styled.div`
max-width:75%;
margin:0 auto;
`;

export default function FormValidation() {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm();
    const onSubmit = (data) => {
        console.log(data);
    };
    return (
        <FormWrap >
            <Form onSubmit={handleSubmit(onSubmit)}>
                <FlexBox className="flexBox">
                    <Form.Field>
                        <label className="formLabel">First Name</label>
                        <input
                            placeholder="First Name"
                            className="formInput"
                            type="text"
                            {...register("firstName", {
                                required: true,
                                maxLength: 10,
                            })}
                        />
                    </Form.Field>
                    {errors.firstName && (
                        <p className="text-error">This field is required</p>
                    )}


                    <Form.Field>
                        <label className="formLabel">Last Name</label>
                        <input
                            placeholder="Last Name"
                            type="text"
                            className="formInput"
                            {...register("lastName", {
                                required: true,
                                maxLength: 10,
                            })}
                        />
                    </Form.Field>
                    {errors.lastName && (
                        <p className="text-error flex-error">This field is required</p>
                    )}

                </FlexBox>

                <Form.Field>
                    <label className="formLabel">Email</label>
                    <input
                        placeholder="Email"
                        type="email"
                        className="formInput"
                        {...register("email", {
                            required: true,
                            pattern:
                                /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                        })}
                    />
                </Form.Field>
                {errors.email && (
                    <p className="text-error">This field is required</p>
                )}





                <Form.Field>
                    <label className="formLabel">Address</label>
                    <textarea
                        placeholder="Address"
                        className="formInput"
                        {...register("address", {
                            required: true,
                        })}
                    />
                </Form.Field>
                {errors.address && (
                    <p className="text-error">This field is required</p>
                )}


                <Form.Field>
                    <label className="formLabel">Country</label>
                    <select
                        name=""
                        id=""
                        placeholder="country"
                        className="formInput"
                        {...register("country", {
                            required: true,
                        })}
                    >
                        <option value="" selected disabled hidden>
                            Select Country
                        </option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                    </select>
                </Form.Field>
                {errors.country && (
                    <p className="text-error">This field is required</p>
                )}

                <FlexBox className="flexBox">
                    <Form.Field>
                        <label className="formLabel">Postal Code</label>
                        <select
                            name=""
                            id=""
                            placeholder="postal"
                            className="formInput"
                            {...register("postal", {
                                required: true,
                            })}
                        >
                            <option value="" selected disabled hidden>
                                Select Postal Code
                            </option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                        </select>
                    </Form.Field>
                    {errors.postal && (
                        <p className="text-error">This field is required</p>
                    )}



                    <Form.Field>
                        <label className="formLabel">Phone</label>
                        <input
                            placeholder="Phone"
                            type="tel"
                            className="formInput"
                            {...register("phone", {
                                required: true,
                                pattern:
                                    /^(?:00971|\+971|0)?(?:50|51|52|55|56|58|2|3|4|6|7|9)\d{7}$/,
                            })}
                        />
                    </Form.Field>
                    {errors.phone && (
                        <p className="text-error flex-error">This field is required</p>
                    )}
                </FlexBox>
                <Button type="submit" className="orangeBtn w-100 text-center">Continue</Button>
            </Form>
        </FormWrap>
    );
}
