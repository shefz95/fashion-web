import React from "react";
import styled from "styled-components";
import arrow from "../img/arrow.png";
import Slider from "react-slick";
import one from "../img/one.jpg";
import two from "../img/two.jpg";
import three from "../img/three.jpg";
import { Button } from "@mui/material";
import { Link } from "react-router-dom";

const Spotlight = () => {
    var settings = {
        dots: false,
        arrows: false,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 2000,
        centerMode: true,
        centerPadding: "30px",
        slidesToShow: 2,
        responsive: [
            {
                breakpoint: 1080,
                settings: {
                    slidesToShow: 1,
                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                },
            },
            {
                breakpoint: 640,
                settings: {
                    slidesToShow: 1,
                },
            },
        ],
    };
    return (
        <SpotWrap>
            <WrapLeft>
                <SpotHead className="mainHeading">
                    Sort out Your <br /> Spring Look
                </SpotHead>
                <SpotSub>
                    We will help to develop every smallest thing into a<br />{" "}
                    big one for your company.
                </SpotSub>
                <Link to="/shop">
                    <Button className="orangeBtn">
                        Shop&emsp;
                        <img src={arrow} alt="icon" />
                    </Button>
                </Link>
            </WrapLeft>
            <WrapRight>
                <Slider {...settings}>
                    <SpotCard>
                        <img src={one} alt="icon" className="slideImage" />
                    </SpotCard>
                    <SpotCard>
                        <img src={two} alt="icon" className="slideImage" />
                    </SpotCard>
                    <SpotCard>
                        <img src={three} alt="icon" className="slideImage" />
                    </SpotCard>
                </Slider>
            </WrapRight>
        </SpotWrap>
    );
};
const SpotWrap = styled.div`
    font-family: "DM Sans";
    display: flex;
    align-items: center;
    @media (max-width: 768px) {
        flex-direction: column;
    }
`;
const WrapLeft = styled.div`
    width: 50%;
    padding-left: 75px;
    @media (max-width: 1080px) {
        width: 100%;
    }
    @media (max-width: 860px) {
        padding-left: 30px;
    }
    @media (max-width: 768px) {
        text-align: center;
        margin-bottom: 50px;
    }
`;
const SpotHead = styled.h1``;
const SpotSub = styled.p`
    font-size: 16px;
    color: #9a9ab0;
    margin-bottom: 50px;
`;

const WrapRight = styled.div`
    width: 50%;
    @media (max-width: 1280px) {
        width: 57%;
    }
    @media (max-width: 1080px) {
        width: 45%;
    }
    @media (max-width: 768px) {
        width: 95%;
    }
    @media (max-width: 640px) {
        width: 75%;
    }
    @media (max-width: 480px) {
        width: 95%;
    }
`;
const SpotCard = styled.div``;
export default Spotlight;
