import React, { useRef } from "react";
import mars from "../img/mars.jpg";
import venus from "../img/venus.jpg";
import titan from "../img/titan.jpg";
import Slider from "react-slick";
import left from "../img/left.png";
import right from "../img/right.png";
import styled from "styled-components";
const Feedback = () => {
    const feedslider = useRef();

    const next = () => {
        feedslider.current.slickNext();
    };
    const previous = () => {
        feedslider.current.slickPrev();
    };
    var settings = {
        dots: false,
        arrows: false,
        infinite: true,
        centerMode: true,
        centerPadding: "0",
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
    };
    const data = [
        {
            id: 1,
            userImg: mars,
            userName: "Jhon Doe",
            userInfo:
                "Tanahair is the friendliest and most efficient company I have ever used. The whole thing takes time to introduce the product and as a result puts forward only the best opportunities that really suit you. they help from start to finish to create a great product identity for your company",
            designation: "Product Designer",
        },
        {
            id: 2,
            userImg: venus,
            userName: "Shalima Hayden",
            userInfo:
                "Tanahair is the friendliest and most efficient company I have ever used. The whole thing takes time to introduce the product and as a result puts forward only the best opportunities that really suit you. they help from start to finish to create a great product identity for your company",
            designation: "Developer",
        },
        {
            id: 3,
            userImg: titan,
            userName: "Nick John",
            userInfo:
                "Tanahair is the friendliest and most efficient company I have ever used. The whole thing takes time to introduce the product and as a result puts forward only the best opportunities that really suit you. they help from start to finish to create a great product identity for your company",
            designation: "Manager",
        },
    ];
    return (
        <FeedbackWrap>
            <Header>What Our Customer Says</Header>
            <Prev onClick={previous}>
                <img src={left} alt="icon" />
            </Prev>
            <FeedbackContent>
                <Slider {...settings} ref={(c) => (feedslider.current = c)}>
                    {data.map((feed) => (
                        <FeedbackCard key={feed.id}>
                            <UserImg>
                                <img
                                    src={feed.userImg}
                                    className="userImage"
                                    alt="image"
                                />
                            </UserImg>
                            <Info>{feed.userInfo}</Info>
                            <UserName>{feed.userName}</UserName>
                            <Designation>{feed.designation}</Designation>
                        </FeedbackCard>
                    ))}
                </Slider>
            </FeedbackContent>
            <Next onClick={next}>
                <img src={right} alt="icon" />
            </Next>
        </FeedbackWrap>
    );
};
const FeedbackWrap = styled.div`
    position: relative;
    margin-bottom: 75px;
    font-family: "DM Sans";
`;
const Header = styled.h1`
    font-family: "Merriweather";
    color: #11142d;
    font-size: 36px;
    margin: 50px 0 40px;
    text-align: center;
`;
const FeedbackContent = styled.div`
    width: 50%;
    margin: 0 auto;
    @media (max-width: 980px) {
        width: 75%;
    }
`;
const FeedbackCard = styled.div`
    background-color: #ffefeb;
    position: relative;
    width: unset !important;
    padding: 30px 60px;
    @media (max-width: 768px) {
        padding: 30px;
    }
`;
const UserImg = styled.div`
    width: 90px;
    height: 90px;
    border-radius: 50%;
    margin: 0 auto 25px;
`;
const Info = styled.p`
    font-size: 14px;
    color: #515151;
    text-align: center;
`;
const UserName = styled.h6`
    font-family: "Merriweather";
    color: #11142d;
    font-size: 22px;
    margin: 25px 0 5px;
    text-align: center;
`;
const Designation = styled.span`
    font-size: 16px;
    color: #515151;
    display: block;
    text-align: center;
`;
const Prev = styled.span`
    position: absolute;
    bottom: 32%;
    left: 20%;
    cursor: pointer;
    z-index: 99;
    @media (max-width: 980px) {
        left: 5%;
    }
`;
const Next = styled.span`
    z-index: 99;
    position: absolute;
    bottom: 32%;
    right: 20%;
    cursor: pointer;
    @media (max-width: 980px) {
        right: 5%;
    }
`;
export default Feedback;
