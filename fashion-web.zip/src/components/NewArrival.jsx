import React, { useRef } from "react";
import styled from "styled-components";
import ProductCard from "./ProductCard";
import mars from "../img/mars.jpg";
import venus from "../img/venus.jpg";
import titan from "../img/titan.jpg";
import Slider from "react-slick";
import left from "../img/left.png";
import right from "../img/right.png";

const NewArrival = () => {
    const slider = useRef();

    const next = () => {
        slider.current.slickNext();
    };
    const previous = () => {
        slider.current.slickPrev();
    };
    var settings = {
        dots: false,
        arrows: false,
        infinite: true,
        centerMode: true,
        centerPadding: "60px",
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1080,
                settings: {
                    slidesToShow: 3,
                },
            },
            {
                breakpoint: 860,
                settings: {
                    slidesToShow: 2,
                },
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                },
            },
        ],
    };
    const data = [
        {
            id: 1,
            bgUrl: mars,
            type: "bag",
            name: "Swetears",
            subcategory: "hi",
            price: "1000",
        },
        {
            id: 2,
            bgUrl: venus,
            type: "clothing",
            name: "Shirts",
            subcategory: "hi",
            price: "1000",
        },
        {
            id: 3,
            bgUrl: titan,
            type: "clothing",
            name: "Jeans",
            subcategory: "hi",
            price: "1000",
        },
        {
            id: 4,
            bgUrl: mars,
            type: "Accessory",
            name: "Swetears",
            subcategory: "hi",
            price: "1000",
        },
        {
            id: 5,
            bgUrl: venus,
            type: "shoes",
            name: "Shirts",
            subcategory: "hi",
            price: "1000",
        },
        {
            id: 6,
            bgUrl: titan,
            type: "wallet",
            name: "Jeans",
            subcategory: "hi",
            price: "1000",
        },
    ];

    return (
        <NewArrivalWrap>
            <WrapHead>
                <WrapHeader>New arrival</WrapHeader>

                <SeeAll>See All</SeeAll>
            </WrapHead>
            <Prev onClick={previous}>
                <img src={left} alt="icon" />
            </Prev>
            <Slider {...settings} ref={(c) => (slider.current = c)}>
                {data.map((category) => (
                    <ProductCard
                        prodImage={category.bgUrl}
                        prodType={category.type}
                        prodName={category.name}
                        subCategory={category.subcategory}
                        prodPrice={category.price}
                    />
                ))}
            </Slider>
            <Next onClick={next}>
                <img src={right} alt="icon" />
            </Next>
        </NewArrivalWrap>
    );
};
const NewArrivalWrap = styled.div`
    position: relative;
    margin: 99px 0;
`;
const SeeAll = styled.span`
    color: #f86338;
    font-size: 22px;
    font-family: "Merriweather";
    cursor: pointer;
`;
const WrapHead = styled.div`
    display: flex;
    padding: 0 80px;
    margin-bottom: 20px;
    align-items: center;
    justify-content: space-between;
`;
const Prev = styled.span`
    position: absolute;
    bottom: 50%;
    left: 5%;
    z-index: 99;
`;
const Next = styled.span`
    z-index: 99;
    position: absolute;
    bottom: 50%;
    right: 5%;
`;
const WrapHeader = styled.h1`
    font-size: 42px;
    color: #11142d;
    font-family: "Merriweather";
`;

export default NewArrival;
