import { BrowserRouter, Route } from "react-router-dom";
import "./App.css";
import Categories from "./components/Categories";
import NewArrival from "./components/NewArrival";
import Cart from "./pages/Cart";
import Home from "./pages/Home";
import ProductPage from "./pages/ProductPage";
import Shop from "./pages/Shop";

function App() {
  return (
    <BrowserRouter>
      <Route exact path="/" component={Home} />
      <Route exact path="/shop" component={Shop} />
      <Route exact path="/shop/:id" component={ProductPage} />
      <Route exact path="/cart" component={Cart} />
    </BrowserRouter>
  )
}

export default App;
